package com.example.petclinic.model;

/**
 * Functional interface to indicate a model is modifiable.
 */
public interface Modifiable {

    int getId();

}
